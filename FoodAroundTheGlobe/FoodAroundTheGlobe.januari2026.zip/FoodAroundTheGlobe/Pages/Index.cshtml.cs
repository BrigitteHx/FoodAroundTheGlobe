using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FoodAroundTheGlobe.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
