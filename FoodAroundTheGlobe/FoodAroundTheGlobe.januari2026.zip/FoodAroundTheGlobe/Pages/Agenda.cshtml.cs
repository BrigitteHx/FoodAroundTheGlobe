using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FoodAroundTheGlobe.Pages
{
    public class AgendaModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
